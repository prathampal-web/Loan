# from flask import Flask, render_template, request
# import mysql.connector

# app = Flask(__name__)

# @app.route('/')
# def home():
#     return render_template("index.html")

# @app.route('/submit', methods=['POST'])
# def submit():
#     name = request.form['name']
#     email = request.form['email']
#     phone = request.form['phone']
#     course = request.form['course']
#     gender = request.form['gender']

#     try:
#         mydb = mysql.connector.connect(
#             host="localhost",
#             user="root",
#             password="root",
#             database="hp_db"
#         )

#         cursor = mydb.cursor()

#         sql = "INSERT INTO students (name, email, phone, course, gender) VALUES (%s, %s, %s, %s, %s)"
#         values = (name, email, phone, course, gender)

#         cursor.execute(sql, values)
#         mydb.commit()

#         return "<h2>Data Inserted Successfully ✅</h2>"

#     except Exception as e:
#         return f"Error: {e}"

# if __name__ == '__main__':
#     app.run(debug=True)




from flask import Flask, render_template, request, redirect
import mysql.connector

app = Flask(__name__)

# Database connection function
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="hp_db"
    )

# HOME PAGE (Insert + View)
@app.route('/')
def home():
    mydb = get_db_connection()
    cursor = mydb.cursor()
    cursor.execute("SELECT * FROM students")
    data = cursor.fetchall()
    return render_template("index.html", students=data)

# INSERT
@app.route('/insert', methods=['POST'])
def insert():
    name = request.form['name']
    email = request.form['email']
    phone = request.form['phone']
    course = request.form['course']
    gender = request.form['gender']

    mydb = get_db_connection()
    cursor = mydb.cursor()

    sql = "INSERT INTO students (name, email, phone, course, gender) VALUES (%s, %s, %s, %s, %s)"
    values = (name, email, phone, course, gender)

    cursor.execute(sql, values)
    mydb.commit()

    return redirect('/')

# DELETE
@app.route('/delete/<int:id>')
def delete(id):
    mydb = get_db_connection()
    cursor = mydb.cursor()
    cursor.execute("DELETE FROM students WHERE id=%s", (id,))
    mydb.commit()
    return redirect('/')

# EDIT PAGE
@app.route('/edit/<int:id>')
def edit(id):
    mydb = get_db_connection()
    cursor = mydb.cursor()
    cursor.execute("SELECT * FROM students WHERE id=%s", (id,))
    student = cursor.fetchone()
    return render_template("edit.html", student=student)

# UPDATE
@app.route('/update/<int:id>', methods=['POST'])
def update(id):
    name = request.form['name']
    email = request.form['email']
    phone = request.form['phone']
    course = request.form['course']
    gender = request.form['gender']

    mydb = get_db_connection()
    cursor = mydb.cursor()

    sql = """UPDATE students 
             SET name=%s, email=%s, phone=%s, course=%s, gender=%s 
             WHERE id=%s"""
    values = (name, email, phone, course, gender, id)

    cursor.execute(sql, values)
    mydb.commit()

    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)