# from flask import Flask,render_template,request
# import mysql.connector

# app=Flask(__name__)

# @app.route('/')
# def index():
#     return render_template('index.html')

# @app.route('/submit', methods=['POST'])
# def submit():
#     name=request.form.get('name')
#     email=request.form.get('email')
#     address=request.form.get('address')
    
#     try:
#         mydb = mysql.connector.connect(
#             host='localhost',
#             user='root',
#             password='root',
#             database='hp_db'
#         )
        
#         cursor = mydb.cursor()
        
#         sql ='INSERT INTO white (name,email,address) VALUES (%s,%s,%s)'
#         values=(name,email,address,)
        
#         cursor.execute(sql,values)
#         mydb.commit()
        
#         cursor.close()
#         mydb.close()
        
#         return '<h2>Data Inserted Successfully'
    
#     except Exception as e:
#         return f'Error: {e}'
    
# if __name__=='__main__':
#     app.run(debug=True) 