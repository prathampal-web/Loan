from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

# =========================
# Database Connection
# =========================
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="hp_db"
    )

# =========================
# Home Page (Form Only)
# =========================
@app.route("/")
def home():
    return render_template("index.html")

# =========================
# Insert Data
# =========================
@app.route("/insert", methods=["POST"])
def insert():
    name = request.form["name"]
    email = request.form["email"]
    phone = request.form["phone"]

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO students (name, email, phone) VALUES (%s,%s,%s)", 
        (name, email, phone)
    )
    conn.commit()
    conn.close()

    # 🔹 CHANGE HERE (Dashboard open nahi hoga)
    return redirect(url_for("home"))

# =========================
# Dashboard (Show Data)
# =========================
@app.route("/dashboard")
def dashboard():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students")
    data = cursor.fetchall()
    conn.close()

    return render_template("dashboard.html", data=data)

# =========================
# Delete
# =========================
@app.route("/delete/<int:id>")
def delete(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM students WHERE id=%s", (id,))
    conn.commit()
    conn.close()

    # 🔹 FIXED (index.html nahi, route name use karo)
    return redirect(url_for("dashboard"))

# =========================
# Edit Page
# =========================
@app.route("/edit/<int:id>")
def edit(id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM students WHERE id=%s", (id,))
    data = cursor.fetchone()
    conn.close()

    return render_template("edit.html", data=data)

# =========================
# Update
# =========================
@app.route("/update/<int:id>", methods=["POST"])
def update(id):
    name = request.form["name"]
    email = request.form["email"]
    phone = request.form["phone"]

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE students SET name=%s, email=%s, phone=%s WHERE id=%s",
        (name, email, phone, id)
    )
    conn.commit()
    conn.close()

    return redirect(url_for("dashboard"))

if __name__ == "__main__":
    app.run(debug=True)
