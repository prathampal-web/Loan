# from flask import Flask, render_template, request, redirect, session
# import mysql.connector
# from werkzeug.security import generate_password_hash, check_password_hash

# app = Flask(__name__)
# app.secret_key = "supersecretkey"

# # Database Connection
# def db():
#     return mysql.connector.connect(
#         host="localhost",
#         user="root",
#         password="root",
#         database="hp_db"
#     )

# # ==========================
# # HOME PAGE
# # ==========================
# @app.route("/")
# def home():
#     if "user" in session:
#         return redirect("/dashboard")
#     return redirect("/login")


# # ==========================
# # REGISTER
# # ==========================
# @app.route("/register", methods=["GET", "POST"])
# def register():
#     if request.method == "POST":
#         name = request.form["name"]
#         email = request.form["email"]
#         password = generate_password_hash(request.form["password"])

#         conn = db()
#         cur = conn.cursor()
#         cur.execute("INSERT INTO users (name, email, password) VALUES (%s,%s,%s)",
#                     (name, email, password))
#         conn.commit()
#         conn.close()

#         return redirect("/login")

#     return render_template("register.html")


# # ==========================
# # LOGIN
# # ==========================
# @app.route("/login", methods=["GET", "POST"])
# def login():
#     if request.method == "POST":
#         email = request.form["email"]
#         password = request.form["password"]

#         conn = db()
#         cur = conn.cursor(dictionary=True)
#         cur.execute("SELECT * FROM users WHERE email=%s", (email,))
#         user = cur.fetchone()
#         conn.close()

#         if user and check_password_hash(user["password"], password):
#             session["user"] = user["name"]
#             return redirect("/dashboard")
#         else:
#             return "Invalid Email or Password"

#     return render_template("login.html")


# # ==========================
# # DASHBOARD
# # ==========================
# @app.route("/dashboard")
# def dashboard():
#     if "user" in session:
#         return render_template("dashboard.html", name=session["user"])
#     return redirect("/login")


# # ==========================
# # LOGOUT
# # ==========================
# @app.route("/logout")
# def logout():
#     session.pop("user", None)
#     return redirect("/login")


# if __name__ == "__main__":
#     app.run(debug=True)
    
    
    
    
from flask import Flask, render_template, request, redirect, session
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "supersecretkey"

# Database Connection
def db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="hp_db"
    )

# ==========================
# HOME PAGE
# ==========================
@app.route("/")
def home():
    if "user" in session:
        return redirect("/dashboard")
    return redirect("/login")


# ==========================
# REGISTER
# ==========================
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        password = generate_password_hash(request.form["password"])

        conn = db()
        cur = conn.cursor()
        cur.execute("INSERT INTO users (name, email, password) VALUES (%s,%s,%s)",
                    (name, email, password))
        conn.commit()
        conn.close()

        return redirect("/login")

    return render_template("register.html")


# ==========================
# LOGIN
# ==========================
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        conn = db()
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT * FROM users WHERE email=%s", (email,))
        user = cur.fetchone()
        conn.close()

        if user and check_password_hash(user["password"], password):
            session["user"] = user["name"]
            return redirect("/dashboard")
        else:
            return "Invalid Email or Password"

    return render_template("login.html")


# ==========================
# DASHBOARD
# ==========================
@app.route("/dashboard")
def dashboard():
    if "user" in session:
        return render_template("dashboard.html", name=session["user"])
    return redirect("/login")


# ==========================
# LOGOUT
# ==========================
@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect("/login")


if __name__ == "__main__":
    app.run(debug=True)