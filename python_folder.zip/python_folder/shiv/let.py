# from flask import Flask, render_template, request
# import mysql.connector

# app = Flask(__name__)

# @app.route('/')
# def home():
#     return render_template("index.html")

# @app.route('/submit', methods=['POST'])
# def submit():
#     name = request.form['name']
#     email = request.form['email']
#     phone = request.form['phone']
#     course = request.form['course']
#     gender = request.form['gender']

#     try:
#         mydb = mysql.connector.connect(
#             host="localhost",
#             user="root",
#             password="root",
#             database="dell_db"
#         )

#         cursor = mydb.cursor()

#         sql = "INSERT INTO us (name, email, phone, course, gender) VALUES (%s, %s, %s, %s, %s)"
#         values = (name, email, phone, course, gender)

#         cursor.execute(sql, values)
#         mydb.commit()

#         return "<h2>Data Inserted Successfully ✅</h2>"

#     except Exception as e:
#         return f"Error: {e}"

# if __name__ == '__main__':
#     app.run(debug=True)



# from flask import Flask,render_template,request,redirect,url_for
# import mysql.connector

# app=Flask(__name__)

# @app.route('/')
# def home():
#     return render_template('index.html')

# @app.route('/submit',methods=['POST'])
# def submit():
#     name=request.form['name']
#     email=request.form['email']
#     phone=request.form['phone']
#     gendre=request.form['gender']
    
#     try:
#         mydb=mysql.connector.connect(
#             host='localhost',
#             user='root',
#             password='root',
#             database='cadd'
#         )

#         cursor=mydb.cursor()
        
#         sql='INSERT INTO uz (name,email,phone,gender) VALUES (%s,%s,%s,%s)'
#         values=(name,email,phone,gendre)
        
#         cursor.execute(sql,values)
#         mydb.commit()
        
#         return redirect(url_for('home'))
#     except Exception as e:
#         return f'Error:{e}'
# if __name__=='__main__':
#     app.run(debug=True)





from flask import Flask,render_template,redirect,request,url_for
import mysql.connector

app=Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/submit',methods=['POST'])
def submit():
    name=request.form['name']
    email=request.form['email']
    phone=request.form['phone']
    gender=request.form['gender']
    
    try:
        mydb=mysql.connector.connect(
            host='localhost',
            user='root',
            password='root',
            database='cadd'
        )
        cursor=mydb.cursor()
        
    
        sql='INSERT INTO uz (name,email,phone,gender) VALUES (%s,%s,%s,%s)'
        values=(name,email,phone,gender)
    
        cursor.execute(sql,values)
        mydb.commit()
    
        return redirect(url_for('home'))
    except Exception as a:
        return f'Error :{a}'
if __name__=='__main__':
    app.run(debug=True)
    